def main():
    print(
        'Welcome to tpux setup script!\n'
        'This script will guide you to setup environment on a new Cloud TPU.\n'
    )

    while True:
        res = input('Are you running on a TPU Pod (instead of a single TPU host)? [y/n]')
        if res in 'yn':
            break
        else:
            print('Please answer "y" or "n"')

    if res == 'n':
        setup_single_host()
    else:  # res == 'y'
        setup_tpu_pod()

def setup_single_host():
    raise NotImplementedError

def setup_tpu_pod():
    raise NotImplementedError
